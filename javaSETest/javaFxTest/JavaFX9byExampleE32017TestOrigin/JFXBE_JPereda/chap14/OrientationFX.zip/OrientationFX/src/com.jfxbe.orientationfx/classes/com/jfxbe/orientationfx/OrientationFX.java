package com.jfxbe.orientationfx;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * javac --module-path libs/jssc.jar -d mods/com.jfxbe.orientationfx $(find src/com.jfxbe.orientationfx -name "*.java")       
 * cp src/com.jfxbe.orientationfx/classes/com/jfxbe/orientationfx/arduino.css mods/com.jfxbe.orientationfx/com/jfxbe/orientationfx
 * java --module-path mods:libs -m com.jfxbe.orientationfx/com.jfxbe.orientationfx.OrientationFX
 *  
 * @author jpereda
 */
public class OrientationFX extends Application {

    private static final double OFFSET_YAW = -180;
    private Serial serial;
    private ArduinoChart arduinoChart;
    private Arduino3D arduino3D;
    private TextField textYaw;
            
    private final BooleanProperty connection = new SimpleBooleanProperty();
    
    private final ChangeListener<String> listener = (obs, ov, nv) -> {
            String[] split = nv.split("\\s");
            long time = Long.parseLong(split[0]);
            double offset = OFFSET_YAW;
            if (!textYaw.getText().isEmpty()) {
                try {
                    offset = Double.parseDouble(textYaw.getText());
                } catch (NumberFormatException nfe) { }
            }
            double yaw = Double.parseDouble(split[1]) + offset;
            double pitch = - Double.parseDouble(split[2]);
            double roll = - Double.parseDouble(split[3]);
            Platform.runLater(() -> {
                arduinoChart.processEvent(time, roll, pitch, yaw);
                arduino3D.processEvent(roll, pitch, yaw);
            });
        };
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        arduinoChart = new ArduinoChart();
        arduino3D = new Arduino3D();
                
        BorderPane root = new BorderPane();
        
        Button buttonStart = new Button();
        buttonStart.setText("Start");
        buttonStart.setOnAction(e -> startSerial());
        
        Button buttonStop = new Button();
        buttonStop.setText("Stop");
        buttonStop.setOnAction(e -> stopSerial());
            
        Label labelConnection = new Label("Not connected");
        connection.addListener((obs, ov, nv) -> labelConnection.setText(nv ? 
                "Connected to: " + serial.getPortName() : "Not connected"));
        labelConnection.setPrefWidth(400);
        
        textYaw = new TextField("" + OFFSET_YAW);
        HBox top = new HBox(buttonStart, buttonStop, new Label("Yaw Offset (º): "), textYaw);
        top.getStyleClass().add("box");
        root.setTop(top);
        
        final VBox chartBox = arduinoChart.createArduinoChart();
        chartBox.setPrefWidth(500);
        HBox center = new HBox(chartBox, arduino3D.createArduino3D());
        center.getStyleClass().add("box");
        center.setPrefHeight(500);
        root.setCenter(center);
        
        HBox bottom = new HBox(labelConnection);
        bottom.getStyleClass().add("box");
        root.setBottom(bottom);
        
        Scene scene = new Scene(root, 1000, 600);
        scene.getStylesheets().add(OrientationFX
                .class.getResource("arduino.css").toExternalForm());
        
        primaryStage.setTitle("OrientationFX");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void stop(){
        stopSerial();
    }
    
    private void startSerial(){
        if (serial == null) {
            serial = new Serial();
        }
        serial.getLine().addListener(listener);
        serial.connect();
        connection.set(!serial.getPortName().isEmpty());
    }
    
    private void stopSerial(){
        if (serial != null) {
            serial.disconnect();
            serial.getLine().removeListener(listener);
            connection.set(false);
            serial = null;
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
