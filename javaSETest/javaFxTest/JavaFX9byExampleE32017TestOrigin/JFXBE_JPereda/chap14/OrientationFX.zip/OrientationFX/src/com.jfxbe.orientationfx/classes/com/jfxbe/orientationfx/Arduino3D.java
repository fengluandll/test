package com.jfxbe.orientationfx;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.SceneAntialiasing;
import javafx.scene.SubScene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.scene.transform.Affine;
import javafx.scene.transform.Translate;

/**
 *
 * @author JosePereda
 */
public class Arduino3D {
    
    private static final int SIZE = 5;
    
    private Affine affine;
    
    private final List<Double> averageRoll = new ArrayList();
    private final List<Double> averagePitch = new ArrayList();
    private final List<Double> averageYaw = new ArrayList();
    
    public VBox createArduino3D() {
        Box board = new Box(300, 10, 200);
        board.setMaterial(new PhongMaterial(Color.web("#008282")));
        Box longHeader = new Box(210, 40, 10);
        longHeader.setMaterial(new PhongMaterial(Color.web("#505050")));
        longHeader.getTransforms().add(new Translate(40, -20, 90));
        Box shortHeader = new Box(170, 40, 10);
        shortHeader.setMaterial(new PhongMaterial(Color.web("#505050")));
        shortHeader.getTransforms().add(new Translate(60, -20, -90));
        
        Group arduino = new Group(board, longHeader, shortHeader);
        affine = new Affine();
        arduino.getTransforms().add(affine);
        
        SubScene subScene = new SubScene(new Group(arduino), 400, 400, true, SceneAntialiasing.BALANCED);
        PerspectiveCamera camera = new PerspectiveCamera();
        camera.setTranslateX(-200);
        camera.setTranslateY(-200);
        camera.setTranslateZ(-50);
        subScene.setCamera(camera);

        VBox vBox = new VBox(new Label("3D Rendering"), subScene);
        vBox.getStyleClass().add("box");
        return vBox;
    }
    
    public void processEvent(double roll, double pitch, double yaw) {
        double avYaw = average(averageYaw, Math.toRadians(yaw));
        double avPitch = average(averagePitch, Math.toRadians(pitch));
        double avRoll = average(averageRoll, Math.toRadians(roll));
        matrixRotateNode(avRoll, avPitch, avYaw);
    }

    private void matrixRotateNode(double roll, double pitch, double yaw) {
        double mxx = Math.cos(pitch) * Math.cos(yaw);
        double mxy = Math.cos(roll) * Math.sin(pitch) + 
                Math.cos(pitch) * Math.sin(roll) * Math.sin(yaw);
        double mxz = Math.sin(pitch) * Math.sin(roll) - 
                Math.cos(pitch) * Math.cos(roll) * Math.sin(yaw);
        double myx = -Math.cos(yaw) * Math.sin(pitch);
        double myy = Math.cos(pitch) * Math.cos(roll) - 
                Math.sin(pitch) * Math.sin(roll) * Math.sin(yaw);
        double myz = Math.cos(pitch) * Math.sin(roll) + 
                Math.cos(roll) * Math.sin(pitch) * Math.sin(yaw);
        double mzx = Math.sin(yaw);
        double mzy = -Math.cos(yaw) * Math.sin(roll);
        double mzz = Math.cos(roll) * Math.cos(yaw);
         
        affine.setToTransform(mxx, mxy, mxz, 0, 
                              myx, myy, myz, 0, 
                              mzx, mzy, mzz, 0);
    }
    
    private double average(List<Double> list, double value) {
        while (list.size() > SIZE) {
            list.remove(0);
        }
        list.add(value);
        
        return list.stream()
                .collect(Collectors.averagingDouble(d -> d));
    }
}
