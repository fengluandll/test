package com.jfxbe.orientationfx;

import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;

/**
 *
 * @author JosePereda
 */
public class ArduinoChart {
    
    private static final int SIZE_MAX = 300;
    
    private LineChart<Number,Number> chart;
    private Series<Number, Number> rollSeries, pitchSeries, yawSeries;
    private NumberAxis xAxis, yAxis;
    
    private Label labelRoll, labelPitch, labelYaw;
    
    public VBox createArduinoChart() {
        xAxis = new NumberAxis();
        xAxis.setLabel("Time");
        xAxis.setAutoRanging(true);
        xAxis.setForceZeroInRange(false);
        xAxis.setTickLabelFormatter(new StringConverter<Number>() {
            @Override
            public String toString(Number t) {
                return new SimpleDateFormat("HH:mm:ss")
                            .format(new Date(t.longValue()));
            }
            @Override
            public Number fromString(String string) {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        });
        yAxis = new NumberAxis();
        yAxis.setLabel("Angle (º)");
        chart = new LineChart<>(xAxis, yAxis);
        chart.setCreateSymbols(true);
        chart.setAnimated(false);
        chart.setLegendVisible(true);
        chart.setTitle("Roll/Pitch/Yaw");
        rollSeries = new Series<>();
        rollSeries.setName("Roll (º)");
        pitchSeries = new Series<>();
        pitchSeries.setName("Pitch (º)");
        yawSeries = new Series<>();
        yawSeries.setName("Yaw (º)");
        
        chart.getData().addAll(rollSeries, pitchSeries, yawSeries); 

        labelRoll = new Label();
        labelPitch = new Label();
        labelYaw = new Label();
        
        final HBox hBox = new HBox(new Label("Values: "), labelRoll, labelPitch, labelYaw);
        hBox.getStyleClass().add("box");
        
        final VBox vBox = new VBox(chart, hBox);
        vBox.getStyleClass().add("box");
        return vBox;
    }
    
    public void processEvent(long time, double roll, double pitch, double yaw) {
        rollSeries.getData().add(new Data(time, roll));
        labelRoll.setText("Roll: " + String.format("%3.2f º", roll));
        if (rollSeries.getData().size() > SIZE_MAX) {
            rollSeries.getData().remove(0);
        }
        
        pitchSeries.getData().add(new Data(time, pitch));
        labelPitch.setText("Pitch: " + String.format("%3.2f º", pitch));
        if (pitchSeries.getData().size() > SIZE_MAX) {
            pitchSeries.getData().remove(0);
        }
        
        yawSeries.getData().add(new Data(time, yaw));
        labelYaw.setText("Yaw: " + String.format("%3.2f º", yaw));
        if (yawSeries.getData().size() > SIZE_MAX) {
            yawSeries.getData().remove(0);
        }
    }
    
}
