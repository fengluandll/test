module com.jfxbe.orientationfx {
    requires javafx.controls;
    requires jssc;
    exports com.jfxbe.orientationfx;
}
