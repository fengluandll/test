module com.jfxbe.gesturemeshes {
    requires javafx.controls;
    exports com.jfxbe.gesturemeshes;
}
