module com.jfxbe.touchevents {
    requires javafx.controls;
    exports com.jfxbe.touchevents;
}
