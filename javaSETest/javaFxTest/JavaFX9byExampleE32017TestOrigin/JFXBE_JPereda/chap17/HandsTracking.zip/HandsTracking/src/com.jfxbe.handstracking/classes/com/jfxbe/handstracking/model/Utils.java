package com.jfxbe.handstracking.model;

import com.leapmotion.leap.Vector;
import java.util.Arrays;
import java.util.List;
import javafx.geometry.Point3D;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Transform;
import javafx.scene.transform.Translate;

/**
 *
 * @author JosePereda
 */
public class Utils {
    
    /**
     * Returns a list of transforms based on a direction and a position. It takes as
     * input the vectors from Leap Motion coordinate system and transforms them into 
     * a translation and a rotation over the JavaFX coordinate system.
     * 
     * A vertical cylinder is taken as a reference for the tranformations, located
     * at the given position.
     * 
     * The translation is given by the item position in the JavaFX system 
     * (position.getX(), -position.getY(), -position.getZ())
     * 
     * The pivot 3DPoint for the rotation is given by the cross product of the item
     * direction in the JavaFX system (direction.getX(), -direction.getY(), 
     * -direction.getZ()) and the cylinder direction (0, -1, 0) in the same system
     * 
     * The angle of rotation is given by the angle between both referred vectors
     * 
     * @param dir A Leap Motion Vector with the direction
     * @param pos A Leap Motion Vector with the position
     * @param yOffset a double coordinate to apply an offset over the item position
     * @return a List of transforms
     */
    public static List<Transform> getTransforms(Vector dir, Vector pos, double yOffset) {
        final double ang = Math.acos(dir.getY() / dir.magnitude());
        
        return Arrays.asList(
                new Translate(pos.getX(), -pos.getY() + yOffset, -pos.getZ()),
                new Rotate(- Math.toDegrees(ang), 0, -yOffset, 0, 
                        new Point3D(-dir.getZ(), 0, -dir.getX())));
    }
}
