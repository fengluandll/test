package com.jfxbe.handstracking.model;

import com.leapmotion.leap.Arm;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.Shape3D;

/**
 *
 * @author JosePereda
 */
public class Forearm {
    
    private final Cylinder cylinder;
    
    public Forearm(Arm arm) {
        PhongMaterial materialArm = new PhongMaterial();
        materialArm.setDiffuseColor(Color.CORNSILK); 
        materialArm.setSpecularColor(Color.rgb(30, 30, 30));
        
        cylinder = new Cylinder(arm.width() / 2d, arm.elbowPosition().minus(arm.wristPosition()).magnitude());
        cylinder.setMaterial(materialArm);
        cylinder.getTransforms().addAll(Utils.getTransforms(arm.direction(), arm.center(), 0));
    }
    
    public Shape3D getForearm() {
        return cylinder;
    }
    
}
