module com.jfxbe.handstracking {
    requires javafx.controls;
    requires LeapJava;
    exports com.jfxbe.handstracking;
}
