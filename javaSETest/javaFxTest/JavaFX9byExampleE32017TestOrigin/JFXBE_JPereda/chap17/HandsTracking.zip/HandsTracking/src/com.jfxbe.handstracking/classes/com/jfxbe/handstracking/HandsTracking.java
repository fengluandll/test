package com.jfxbe.handstracking;

import com.jfxbe.handstracking.model.Forearm;
import com.jfxbe.handstracking.model.Joint;
import com.jfxbe.handstracking.model.Pair;
import com.jfxbe.handstracking.model.Phalanx;
import com.leapmotion.leap.Arm;
import com.leapmotion.leap.Bone;
import com.leapmotion.leap.Controller;
import java.util.List;
import java.util.stream.Collectors;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.PointLight;
import javafx.scene.Scene;
import javafx.scene.SceneAntialiasing;
import javafx.scene.SubScene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;

/**
 *  javac --module-path libs/LeapJava.jar -d mods/com.jfxbe.handstracking $(find src/com.jfxbe.handstracking -name "*.java")                     
 *  java -Djava.library.path=/Users/JosePereda/Downloads/LeapSDK/lib/ --module-path mods:libs -m com.jfxbe.handstracking/com.jfxbe.handstracking.HandsTracking
 *  
 * @author JosePereda
 */
public class HandsTracking extends Application {

    private LeapListener listener = null;
    private Controller controller = null;
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        listener = new LeapListener();
        controller = new Controller();
        controller.addListener(listener);
        
        final PerspectiveCamera camera = new PerspectiveCamera();
        camera.setFieldOfView(60);
        camera.getTransforms().addAll(new Translate(-400, -500, 200));

        final PointLight pointLight = new PointLight(Color.ANTIQUEWHITE);
        pointLight.setTranslateX(0);
        pointLight.setTranslateY(-1000);
        pointLight.setTranslateZ(-800);
        
        final Group root = new Group(pointLight);
        
        final Group root3D = new Group(camera, root);
        final SubScene subScene = new SubScene(root3D, 800, 600, true, SceneAntialiasing.BALANCED);
        subScene.setCamera(camera);
        
        Scene scene = new Scene(new AnchorPane(subScene), 800, 600, Color.WHITESMOKE);
        
        listener.doneListProperty().addListener((obs, ov, nv) -> {
            if (nv) {
                List<Bone> bones = listener.getBones();
                List<Arm> arms = listener.getArms();
                List<Pair> joints = listener.getJoints();
                
                Platform.runLater(() -> {
                    root.getChildren().setAll(pointLight);
                    
                    root.getChildren().addAll(bones.stream()
                            .filter(bone -> bone.isValid() && bone.length() > 0)
                            .map(Phalanx::new)
                            .map(Phalanx::getPhalanx)
                            .collect(Collectors.toList()));
                    
                    root.getChildren().addAll(joints.stream()
                            .map(Joint::new)
                            .map(Joint::getJoint)
                            .collect(Collectors.toList()));
                    
                    root.getChildren().addAll(arms.stream()
                            .filter(Arm::isValid)
                            .map(Forearm::new)
                            .map(Forearm::getForearm)
                            .collect(Collectors.toList()));
                });
            }
        });
        
        primaryStage.setTitle("Hand Tracking with Leap Motion");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    @Override
    public void stop(){
        controller.removeListener(listener);
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
