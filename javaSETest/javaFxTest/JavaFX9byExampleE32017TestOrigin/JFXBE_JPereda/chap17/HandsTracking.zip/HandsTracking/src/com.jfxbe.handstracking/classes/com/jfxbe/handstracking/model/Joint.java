package com.jfxbe.handstracking.model;

import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.Shape3D;

/**
 *
 * @author JosePereda
 */
public class Joint {
    
    private final Cylinder cylinder;
    
    public Joint(Pair pair) {
        PhongMaterial material = new PhongMaterial();
        material.setSpecularColor(Color.rgb(30, 30, 30));
        
        cylinder = new Cylinder(pair.getWidth() / 2d, pair.getV0().distanceTo(pair.getV1()));
        cylinder.setMaterial(material);
        cylinder.getTransforms().addAll(Utils.getTransforms(pair.getDirection(), pair.getCenter(), 0));
    }
    
    public Shape3D getJoint() {
        return cylinder;
    }
    
}
