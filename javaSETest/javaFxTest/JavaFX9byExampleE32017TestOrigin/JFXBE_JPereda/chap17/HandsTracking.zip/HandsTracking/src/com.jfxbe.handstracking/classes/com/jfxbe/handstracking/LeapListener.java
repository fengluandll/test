package com.jfxbe.handstracking;

import com.jfxbe.handstracking.model.Pair;
import com.leapmotion.leap.Arm;
import com.leapmotion.leap.Bone;
import com.leapmotion.leap.Bone.Type;
import com.leapmotion.leap.Controller;
import com.leapmotion.leap.Finger;
import com.leapmotion.leap.FingerList;
import com.leapmotion.leap.Frame;
import com.leapmotion.leap.Hand;
import com.leapmotion.leap.Listener;
import com.leapmotion.leap.Screen;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

/**
 *
 * @author Jose Pereda 
*/
public class LeapListener extends Listener {
    
    private final BooleanProperty doneList = new SimpleBooleanProperty(false);
    private final List<Bone> bones = new ArrayList<>();
    private final List<Arm> arms = new ArrayList<>();
    private final List<Pair> joints = new ArrayList<>();
    
    @Override
    public void onFrame(Controller controller) {
        Frame frame = controller.frame();
        doneList.set(false);
        bones.clear();
        arms.clear();
        joints.clear();
        
        if (!frame.hands().isEmpty()) {
            Screen screen = controller.locatedScreens().get(0);
            if (screen != null && screen.isValid()) {
                for (Finger finger : frame.fingers()) {
                    if (finger.isValid()) {
                        for (Type b : Type.values()) {
                            if ((!finger.type().equals(Finger.Type.TYPE_RING) && 
                                !finger.type().equals(Finger.Type.TYPE_MIDDLE)) || 
                                !b.equals(Type.TYPE_METACARPAL)) {
                                bones.add(finger.bone(b));
                            }
                        }
                    }
                }
                for (Hand h : frame.hands()) {
                    if (h.isValid()) {
                        // arm
                        arms.add(h.arm());
                        
                        FingerList fingers = h.fingers();
                        Finger index = null, middle = null, ring = null, pinky = null;
                        for (Finger f : fingers) {
                            if (f.isFinger() && f.isValid()) {
                                switch (f.type()) {
                                    case TYPE_INDEX: index = f; break;
                                    case TYPE_MIDDLE: middle = f; break;
                                    case TYPE_RING: ring = f; break;
                                    case TYPE_PINKY: pinky = f; break;
                                }
                            }
                        }
                        // joints
                        if (index != null && middle != null) {
                            Pair p = new Pair(index.bone(Type.TYPE_METACARPAL).nextJoint(),
                                            middle.bone(Type.TYPE_METACARPAL).nextJoint(),
                                            bones.get(0).width() / 2d);
                            joints.add(p);
                        }
                        if (middle != null && ring != null) {
                            Pair p = new Pair(middle.bone(Type.TYPE_METACARPAL).nextJoint(),
                                            ring.bone(Type.TYPE_METACARPAL).nextJoint(),
                                            bones.get(0).width() / 2d);
                            joints.add(p);
                        }
                        if (ring != null && pinky != null) {
                            Pair p = new Pair(ring.bone(Type.TYPE_METACARPAL).nextJoint(),
                                            pinky.bone(Type.TYPE_METACARPAL).nextJoint(),
                                            bones.get(0).width() / 2d);
                            joints.add(p);
                        }
                        if (index != null && pinky != null) {
                            Pair p = new Pair(index.bone(Type.TYPE_METACARPAL).prevJoint(),
                                            pinky.bone(Type.TYPE_METACARPAL).prevJoint(),
                                            bones.get(0).width() / 2d);
                            joints.add(p);
                        }        
                    }
                }
            }
        }
        
        doneList.set(!bones.isEmpty() || !arms.isEmpty());
    }
    
    public List<Bone> getBones() { 
        return bones.stream().collect(Collectors.toList());
    }
    public List<Arm> getArms() { 
        return arms.stream().collect(Collectors.toList());
    }
    public List<Pair> getJoints() { 
        return joints.stream().collect(Collectors.toList());
    }
    
    public BooleanProperty doneListProperty() { 
        return doneList; 
    }
    
}

