package com.jfxbe.handstracking.model;

import com.leapmotion.leap.Bone;
import com.leapmotion.leap.Bone.Type;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Cylinder;
import javafx.scene.shape.Sphere;

/**
 *
 * @author JosePereda
 */
public class Phalanx {
    
    private final Bone bone;
    private final Cylinder phalanx;
    private final Sphere joint;
    private final Sphere carpoMetaCarpalJoint;
    
    public Phalanx(Bone bone) {
        this.bone = bone;
        PhongMaterial materialPhalanx = new PhongMaterial();
        materialPhalanx.setSpecularColor(Color.rgb(50, 50, 50));
        PhongMaterial materialJoint = new PhongMaterial(Color.BLUE);
        materialJoint.setSpecularColor(Color.rgb(50, 50, 50));
        
        phalanx = new Cylinder(0.8 * bone.width() / 2d, bone.length());
        phalanx.setMaterial(materialPhalanx);
        phalanx.getTransforms().addAll(Utils.getTransforms(bone.direction(), bone.center(), 0));

        joint = new Sphere(bone.width() / 2d);
        joint.setMaterial(materialJoint);
        joint.getTransforms().addAll(Utils.getTransforms(bone.direction(), bone.center(), bone.length() / 2d));
        
        carpoMetaCarpalJoint = new Sphere(bone.width() / 2d);
        carpoMetaCarpalJoint.setMaterial(materialJoint);
        carpoMetaCarpalJoint.getTransforms().addAll(Utils.getTransforms(bone.direction(), bone.center(), - bone.length() / 2d));
    }
    
    public Group getPhalanx() {
        if (bone.type().equals(Type.TYPE_METACARPAL)) {
            return new Group(phalanx, carpoMetaCarpalJoint);
        } else if (bone.type().equals(Type.TYPE_PROXIMAL)) {
            return new Group(phalanx, joint, carpoMetaCarpalJoint);
        }
        return new Group(phalanx, joint);
    }
    
}
