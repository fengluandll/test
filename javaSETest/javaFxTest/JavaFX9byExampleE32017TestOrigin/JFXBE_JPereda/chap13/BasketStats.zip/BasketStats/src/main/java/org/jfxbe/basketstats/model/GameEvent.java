package org.jfxbe.basketstats.model;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

/**
 *
 * @author JosePereda
 */
public class GameEvent {
    
    private int score;
    private long dateTime;
    private int period;
    private int team;
    private String partialScore;
    
    /**
     * Game event when a team scores
     * @param score 0, 1, 2, 3. 0 means other game event
     * @param dateTime
     * @param period 1 to 4, 5 means game ended
     * @param team 1 for team A, 2 for team B, 0 for other game event
     */
    public GameEvent(int score, long dateTime, int period, int team) {
        this.score = score;
        this.dateTime = dateTime;
        this.period = period;
        this.team = team;
    }

    /**
     * Game event when the game starts a period or ends
     * @param dateTime
     * @param period 
     */
    public GameEvent(LocalDateTime dateTime, int period) {
        this(0, dateTime.toInstant(ZoneOffset.UTC).getEpochSecond(), period, 0);
    }
    
    public GameEvent() {
        this(0, 0, 0, 0);
    }
    
    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public long getDateTime() {
        return dateTime;
    }
    
    public LocalDateTime getLocalDateTime() {
        return LocalDateTime.ofEpochSecond(dateTime, 0, ZoneOffset.UTC);
    }

    public void setDateTime(long dateTime) {
        this.dateTime = dateTime;
    }

    public int getPeriod() {
        return period;
    }

    public void setPeriod(int period) {
        this.period = period;
    }

    public int getTeam() {
        return team;
    }

    public void setTeam(int team) {
        this.team = team;
    }

    public String getPartialScore() {
        return partialScore;
    }

    public void setPartialScore(String partialScore) {
        this.partialScore = partialScore;
    }

    @Override
    public String toString() {
        return "GameEvent{" + "score=" + score + ", dateTime=" + dateTime + 
                ", period=" + period + ", team=" + team + 
                ", partialScore=" + partialScore + '}';
    }
    
}
