package org.jfxbe.basketstats.utils;

import com.gluonhq.charm.down.Services;
import com.gluonhq.charm.down.plugins.StorageService;
import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.List;
import org.jfxbe.basketstats.views.AppViewManager;
import org.jfxbe.basketstats.views.BoardPresenter;

/**
 *
 * @author JosePereda
 */
public class GameUtils {
    
    public static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter
            .ofLocalizedDate(FormatStyle.SHORT);
    
    public static LocalDate getLocalDateFromGame(String game) {
        String[] split = game.split("-");
        if (split.length == 5) {
            return LocalDate.ofEpochDay(Long.parseLong(split[3]));
        }
        return LocalDate.now();
    }
    
    public static void restoreGame(String gameName) {
        AppViewManager.BOARD_VIEW.switchView().ifPresent(presenter -> 
            ((BoardPresenter) presenter).restoreGame(gameName));
    }
    
    public static List<String> retrieveGames() {
        File root = Services.get(StorageService.class)
                .flatMap(storage -> storage.getPrivateStorage())
                .orElseThrow(() -> new RuntimeException("No storage found"));
        List<String> list = new ArrayList<>();
        for (File file : root.listFiles((dir, name) -> name.startsWith("Game") 
                && name.endsWith(".gam"))) {
            list.add(file.getName());
        }
        return list;
    }
}
