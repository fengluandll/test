package org.jfxbe.basketstats.views.cells;

import org.jfxbe.basketstats.utils.GameUtils;
import com.gluonhq.charm.glisten.control.CharmListCell;
import com.gluonhq.charm.glisten.control.ListTile;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import java.text.MessageFormat;
import java.util.ResourceBundle;

/**
 *
 * @author JosePereda
 */
public class GameListCell extends CharmListCell<String> {
    
    private final ListTile tile;
    private String gameName;
    
    private final ResourceBundle resources;
    
    public GameListCell(ResourceBundle resources) {
        this.resources = resources;
        
        tile = new ListTile();
        tile.setPrimaryGraphic(MaterialDesignIcon.GAMES.graphic());
        tile.setSecondaryGraphic(MaterialDesignIcon.CHEVRON_RIGHT.graphic());
        tile.getSecondaryGraphic().setOnMousePressed(e -> GameUtils.restoreGame(gameName));
    }
    
    @Override
    public void updateItem(String item, boolean empty) {
        super.updateItem(item, empty); 
        if (item != null && !empty) {
            gameName = item;
            String[] split = item.split("-");
            tile.setTextLine(0, MessageFormat.format(
                    resources.getString("main.listview.game"), split[1], split[2]));
            tile.setTextLine(1, GameUtils.getLocalDateFromGame(item)
                    .format(GameUtils.DATE_FORMAT));
            setGraphic(tile);
        } else {
            setGraphic(null);
        }
    }

}
