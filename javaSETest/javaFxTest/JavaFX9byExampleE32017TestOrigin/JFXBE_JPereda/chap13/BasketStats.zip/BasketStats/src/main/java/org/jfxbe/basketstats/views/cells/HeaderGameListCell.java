package org.jfxbe.basketstats.views.cells;

import org.jfxbe.basketstats.utils.GameUtils;
import com.gluonhq.charm.glisten.control.CharmListCell;

/**
 *
 * @author JosePereda
 */
public class HeaderGameListCell extends CharmListCell<String> {
    
    @Override
    public void updateItem(String item, boolean empty) {
        super.updateItem(item, empty); 
        if (item != null && !empty) {
            setText(GameUtils.getLocalDateFromGame(item).format(GameUtils.DATE_FORMAT));
        } else {
            setText(null);
        }
    }

}
