package org.jfxbe.basketstats.model;

import java.time.LocalDateTime;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author JosePereda
 */
public class Game {
    
    private final ListProperty<GameEvent> gameEvents;
    
    public Game() {
        gameEvents = new SimpleListProperty<>(FXCollections.observableArrayList());
    }
    
    private final IntegerProperty scoreA = new SimpleIntegerProperty(this, "scoreA", 0);
    public final IntegerProperty scoreAProperty() { return scoreA; }
    public final int getScoreA() { return scoreA.get(); }
    public final void setScoreA(int value) { scoreA.set(value); }
    
    private final IntegerProperty scoreB = new SimpleIntegerProperty(this, "scoreB", 0);
    public final IntegerProperty scoreBProperty() { return scoreB; }
    public final int getScoreB() { return scoreB.get(); }
    public final void setScoreB(int value) { scoreB.set(value); }
    
    private final StringProperty teamA = new SimpleStringProperty(this, "teamA", "");
    public final StringProperty teamAProperty() { return teamA; }
    public final String getTeamA() { return teamA.get(); }
    public final void setTeamA(String teamA) { this.teamA.set(teamA); }

    private final StringProperty teamB = new SimpleStringProperty(this, "teamB", "");
    public final StringProperty teamBProperty() { return teamB; }
    public final String getTeamB() { return teamB.get(); }
    public final void setTeamB(String teamB) { this.teamB.set(teamB); }

    private final ObjectProperty<LocalDateTime> localDateTime = 
            new SimpleObjectProperty<>(this, "localDate", LocalDateTime.now());
    public final ObjectProperty<LocalDateTime> localDateTimeProperty() { 
        return localDateTime; }
    public final LocalDateTime getLocalDateTime() { return localDateTime.get(); }
    public final void setLocalDateTime(LocalDateTime localDateTime) { 
        this.localDateTime.set(localDateTime); }

    public ListProperty<GameEvent> gameEventsProperty() { return gameEvents; }
    public ObservableList<GameEvent> getGameEvents() { return gameEvents.get(); }
    public void setGameEvents(ObservableList<GameEvent> gluonGame) { 
        gameEvents.set(gluonGame); }

    public final String getGameName() {
        return "Game-" + teamA.get() + "-" + teamB.get() + "-" + 
                localDateTime.get().toLocalDate().toEpochDay() + "-" +
                localDateTime.get().toLocalTime().toSecondOfDay() + ".gam";
    }

    @Override
    public String toString() {
        return "Game{" + "teamA=" + teamA.get() + ", teamB=" + teamB.get() + 
                ", localDateTime=" + localDateTime.get() + ", scoreA=" + scoreA.get() + 
                ", scoreB=" + scoreB.get() + '}';
    }
    
}
