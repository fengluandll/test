package org.jfxbe.basketstats.views.cells;

import com.airhacks.afterburner.injection.Injector;
import com.gluonhq.charm.glisten.control.CharmListCell;
import com.gluonhq.charm.glisten.control.ListTile;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import java.text.MessageFormat;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ResourceBundle;
import javafx.scene.control.Label;
import org.jfxbe.basketstats.model.GameEvent;
import org.jfxbe.basketstats.service.Service;

/**
 *
 * @author JosePereda
 */
public class GameEventListCell extends CharmListCell<GameEvent> {
    
    private final DateTimeFormatter formatter = DateTimeFormatter
                    .ofLocalizedDateTime(FormatStyle.SHORT, FormatStyle.MEDIUM);
    private final ListTile tile;
     
    private final Service service;
    private final ResourceBundle resources;
    
    public GameEventListCell(ResourceBundle resources) {
        service = Injector.instantiateModelOrService(Service.class);
        this.resources = resources;
        tile = new ListTile();
        setGraphic(tile);
    }
            
    @Override
    public void updateItem(GameEvent item, boolean empty) {
        super.updateItem(item, empty); 
        if (item == null || empty) {
            setGraphic(null);
        } else {
            updateTile(item);
            setGraphic(tile);
        }
    }

    private void updateTile(GameEvent item) {
        switch (item.getTeam()) {
            case 1:
                tile.setPrimaryGraphic(MaterialDesignIcon.LOOKS_ONE.graphic());
                tile.setTextLine(0, MessageFormat.format(
                        resources.getString("board.listview.score"), 
                        service.getGame().getTeamA(), item.getScore()));
                break;
            case 2:
                tile.setPrimaryGraphic(MaterialDesignIcon.LOOKS_TWO.graphic());
                tile.setTextLine(0, MessageFormat.format(
                        resources.getString("board.listview.score"), 
                        service.getGame().getTeamB(), item.getScore()));
                break;
            default:
                if (item.getPeriod() < 5) {
                    tile.setPrimaryGraphic(MaterialDesignIcon.TIMER.graphic());
                    tile.setTextLine(0, MessageFormat.format(
                            resources.getString("board.listview.start"), item.getPeriod()));
                } else {
                    tile.setPrimaryGraphic(MaterialDesignIcon.TIMER_OFF.graphic());
                    tile.setTextLine(0, resources.getString("board.listview.end"));
                }   
                break;
        }
        tile.setTextLine(1, formatter.format(item.getLocalDateTime()));
        final Label partial = new Label(item.getPartialScore());
        partial.getStyleClass().add("partial");
        tile.setSecondaryGraphic(partial);
    }
    
}
