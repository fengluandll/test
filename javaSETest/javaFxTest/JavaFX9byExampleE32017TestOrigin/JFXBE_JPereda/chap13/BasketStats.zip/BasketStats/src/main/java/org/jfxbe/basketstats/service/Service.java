package org.jfxbe.basketstats.service;

import com.gluonhq.cloudlink.client.data.DataClient;
import com.gluonhq.cloudlink.client.data.DataClientBuilder;
import com.gluonhq.cloudlink.client.data.OperationMode;
import com.gluonhq.cloudlink.client.data.SyncFlag;
import com.gluonhq.connect.GluonObservableList;
import com.gluonhq.connect.provider.DataProvider;
import javafx.beans.property.ListProperty;
import javax.annotation.PostConstruct;
import org.jfxbe.basketstats.model.Game;
import org.jfxbe.basketstats.model.GameEvent;

/**
 *
 * @author JosePereda
 */
public class Service {
    
    private DataClient dataClient;
    
    private Game game;

    @PostConstruct
    public void postConstruct() {
        dataClient = DataClientBuilder.create()
                .operationMode(OperationMode.LOCAL_ONLY)
                .build();
        
        game = new Game();
    }
    
    public GluonObservableList<GameEvent> retrieveGame(String nameGame) {
        game.setGameEvents(null);
        
        return DataProvider.retrieveList(dataClient.createListDataReader(nameGame, 
                GameEvent.class,
                SyncFlag.LIST_WRITE_THROUGH, SyncFlag.OBJECT_WRITE_THROUGH));
    }
    
    public void addGameEvent(GameEvent gameEvent) {
        updateScore(gameEvent);
        gameEvent.setPartialScore("" + game.getScoreA() + " :: " + game.getScoreB());
        game.getGameEvents().add(gameEvent);
    }

    public Game getGame() {
        return game;
    }

    public final ListProperty<GameEvent> gameEventsProperty() {
        return game.gameEventsProperty();
    }
    
    public void updateScore(GameEvent event) {
        switch (event.getTeam()) {
            case 0: 
                if (event.getPeriod() == 1) {
                    game.setScoreA(0);
                    game.setScoreB(0);
                }
                break;
            case 1: 
                game.setScoreA(game.getScoreA() + event.getScore());
                break;
            case 2: 
                game.setScoreB(game.getScoreB() + event.getScore());
                break; 
        }
    }
}
