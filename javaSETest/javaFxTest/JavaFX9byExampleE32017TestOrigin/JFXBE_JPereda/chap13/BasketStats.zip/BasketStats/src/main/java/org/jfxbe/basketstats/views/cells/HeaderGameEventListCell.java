package org.jfxbe.basketstats.views.cells;

import com.gluonhq.charm.glisten.control.CharmListCell;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import java.util.ResourceBundle;
import javafx.scene.control.Label;
import org.jfxbe.basketstats.model.GameEvent;

/**
 *
 * @author JosePereda
 */
public class HeaderGameEventListCell extends CharmListCell<GameEvent> {
    
    private final Label label;
     
    private final ResourceBundle resources;
    
    public HeaderGameEventListCell(ResourceBundle resources) {
        this.resources = resources;
        label = new Label();
        label.getStyleClass().add("header");
        label.setGraphic(MaterialDesignIcon.TIMER.graphic());
    }
            
    @Override
    public void updateItem(GameEvent item, boolean empty) {
        super.updateItem(item, empty); 
        if (item != null && !empty) {
            label.setText(item.getPeriod() < 5 ? String.valueOf(item.getPeriod()) : 
                    resources.getString("board.listview.end"));
            setGraphic(label);
        } else {
            setGraphic(null);
        }
    }

}
