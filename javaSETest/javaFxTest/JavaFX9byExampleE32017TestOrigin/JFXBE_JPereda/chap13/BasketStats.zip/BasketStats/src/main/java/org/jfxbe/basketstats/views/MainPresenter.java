package org.jfxbe.basketstats.views;

import static com.gluonhq.charm.glisten.afterburner.DefaultDrawerManager.DRAWER_LAYER;
import com.gluonhq.charm.glisten.afterburner.GluonPresenter;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.control.CharmListView;
import com.gluonhq.charm.glisten.control.TextField;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javax.inject.Inject;
import org.jfxbe.basketstats.BasketStats;
import org.jfxbe.basketstats.service.Service;
import org.jfxbe.basketstats.utils.GameUtils;
import org.jfxbe.basketstats.views.cells.GameListCell;
import org.jfxbe.basketstats.views.cells.HeaderGameListCell;

/**
 *
 * @author JosePereda
 */
public class MainPresenter extends GluonPresenter<BasketStats> {

    @Inject private Service service; 
    
    @FXML private View main;
    @FXML private GridPane gridNew;
    @FXML private TextField textNameA, textNameB;
    @FXML private Button buttonNew;
    @FXML private VBox restoreBox;
    @FXML private CharmListView<String, LocalDate> gameList;
    @FXML private ToggleButton newToggle, restoreToggle;
    @FXML private ResourceBundle resources;
    
    public void initialize() {
        main.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = getApp().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e -> 
                        getApp().showLayer(DRAWER_LAYER)));
                appBar.setTitleText(resources.getString("main.app.title"));
            }
        });
        
        buttonNew.disableProperty().bind(textNameA.textProperty().isEmpty()
                .or(textNameB.textProperty().isEmpty())
                .or(textNameA.textProperty().isEqualTo(textNameB.textProperty())));
        
        buttonNew.setOnAction(e -> {
            service.getGame().setTeamA(textNameA.getText());
            service.getGame().setTeamB(textNameB.getText());
            service.getGame().setLocalDateTime(LocalDateTime.now());
            GameUtils.restoreGame(service.getGame().getGameName());
        });
        
        restoreBox.managedProperty().bind(restoreBox.visibleProperty());
        gridNew.managedProperty().bind(gridNew.visibleProperty());
        
        gameList.setPlaceholder(new Label(resources.getString("main.listview.noitems")));
        gameList.setHeadersFunction(GameUtils::getLocalDateFromGame);
        gameList.setHeaderCellFactory(p -> new HeaderGameListCell());
        gameList.setHeaderComparator((l1, l2) -> l2.compareTo(l1));
        
        gameList.setCellFactory(p -> new GameListCell(resources));
        
        restoreToggle.selectedProperty().addListener((obs, ov, nv) -> {
            if (nv) {
                gridNew.setVisible(false);
                restoreBox.setVisible(true);
                gameList.setItems(FXCollections.observableArrayList(GameUtils.retrieveGames()));
            }
        });
        
        newToggle.selectedProperty().addListener((obs, ov, nv) -> {
            if (nv) {
                restoreBox.setVisible(false);
                gridNew.setVisible(true);
            }
        });
        newToggle.setSelected(true);
    }
    
}
