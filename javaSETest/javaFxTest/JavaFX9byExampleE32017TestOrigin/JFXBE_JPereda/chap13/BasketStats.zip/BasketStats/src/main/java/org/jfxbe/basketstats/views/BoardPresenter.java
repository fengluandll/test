package org.jfxbe.basketstats.views;

import static com.gluonhq.charm.glisten.afterburner.DefaultDrawerManager.DRAWER_LAYER;
import com.gluonhq.charm.glisten.afterburner.GluonPresenter;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.control.CharmListView;
import com.gluonhq.charm.glisten.control.DropdownButton;
import com.gluonhq.charm.glisten.control.ExpansionPanel;
import com.gluonhq.charm.glisten.control.ExpansionPanelContainer;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import com.gluonhq.connect.GluonObservableList;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.util.StringConverter;
import javax.inject.Inject;
import org.jfxbe.basketstats.BasketStats;
import org.jfxbe.basketstats.model.GameEvent;
import org.jfxbe.basketstats.service.Service;
import org.jfxbe.basketstats.views.cells.GameEventListCell;
import org.jfxbe.basketstats.views.cells.HeaderGameEventListCell;

/**
 *
 * @author JosePereda
 */
public class BoardPresenter extends GluonPresenter<BasketStats> {

    @Inject private Service service;
    
    @FXML private View board;
    @FXML private ExpansionPanelContainer expansion;
    @FXML private Label labelTeamA, labelTeamB;
    @FXML private Label scoreTeamA, scoreTeamB, globalScore;
    @FXML private Button plusOneTeamA, plusTwoTeamA, plusThreeTeamA;
    @FXML private Button plusOneTeamB, plusTwoTeamB, plusThreeTeamB;
    @FXML private DropdownButton dropdown;
    @FXML private MenuItem period1, period2, period3, period4;
    @FXML private CharmListView<GameEvent, Integer> listView;
    @FXML private LineChart<Number, Number> chart;
    @FXML private NumberAxis xAxis, yAxis;
    @FXML private ResourceBundle resources;
    
    private Button buttonStart, buttonStop;
    private List<Button> buttons;
    private List<MenuItem> periods;
    private final IntegerProperty period = new SimpleIntegerProperty();
    private Series<Number, Number> teamASeries, teamBSeries;
    
    public void initialize() {
        buttons = Arrays.asList(plusOneTeamA, plusTwoTeamA, plusThreeTeamA, 
                plusOneTeamB, plusTwoTeamB, plusThreeTeamB);
        periods = Arrays.asList(period1, period2, period3, period4);
        
        enableGame(false);
        
        buttonStart = MaterialDesignIcon.PLAY_CIRCLE_OUTLINE
                        .button(e -> startGame());
        buttonStop = MaterialDesignIcon.STOP.button(e -> stopGame());
        buttonStart.setDisable(true);
        buttonStop.setDisable(true);
        
        board.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = getApp().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e -> 
                        getApp().showLayer(DRAWER_LAYER)));
                appBar.setTitleText(resources.getString("board.app.title"));
                appBar.getActionItems().addAll(buttonStart, buttonStop);
            }
        });
        
        for (ExpansionPanel panel : expansion.getItems()) {
            panel.expandedProperty().addListener((obs, ov, nv) -> {
                if (nv) {
                    for (ExpansionPanel otherPanel : expansion.getItems()) {
                        if (!otherPanel.equals(panel)) {
                            otherPanel.setExpanded(false);
                        }
                    }
                }
            });
        }
        
        period2.setOnAction(e -> addPeriodEvent(2));
        period3.setOnAction(e -> addPeriodEvent(3));
        period4.setOnAction(e -> addPeriodEvent(4));
        
        plusOneTeamA.setOnAction(e -> addScoreEvent(1, 1));
        plusTwoTeamA.setOnAction(e -> addScoreEvent(2, 1));
        plusThreeTeamA.setOnAction(e -> addScoreEvent(3, 1));
        plusOneTeamB.setOnAction(e -> addScoreEvent(1, 2));
        plusTwoTeamB.setOnAction(e -> addScoreEvent(2, 2));
        plusThreeTeamB.setOnAction(e -> addScoreEvent(3, 2));
        
        labelTeamA.textProperty().bind(service.getGame().teamAProperty());
        labelTeamB.textProperty().bind(service.getGame().teamBProperty());
        scoreTeamA.textProperty().bind(service.getGame().scoreAProperty().asString());
        scoreTeamB.textProperty().bind(service.getGame().scoreBProperty().asString());
        globalScore.textProperty().bind(Bindings.createStringBinding(() -> {
            String p;
            if (period.get() < 5) {
                p = MessageFormat.format(resources.getString("board.expansion.score"), 
                        period.get());
            } else {
                p = resources.getString("board.listview.end");
            }
            return String.format("(%s)   %s :: %s", p, scoreTeamA.getText(), 
                    scoreTeamB.getText());
        }, period, scoreTeamA.textProperty(), scoreTeamB.textProperty()));
    
        // CharmListView
        listView.setHeadersFunction(GameEvent::getPeriod);
        listView.setPlaceholder(new Label(resources.getString("board.listview.noitems")));
        
        listView.setComparator((GameEvent e1, GameEvent e2) -> 
                Long.compare(e1.getDateTime(), e2.getDateTime()));
        listView.setHeaderCellFactory(p -> new HeaderGameEventListCell(resources));
        listView.setCellFactory(p -> new GameEventListCell(resources));
        listView.setItems(service.gameEventsProperty());
        
        // Chart
        xAxis.setAutoRanging(true);
        xAxis.setForceZeroInRange(false);
        xAxis.setTickLabelFormatter(new StringConverter<Number>() {
            @Override
            public String toString(Number t) {
                return DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM)
                            .format(LocalDateTime.ofEpochSecond(t.longValue(), 0, 
                                    ZoneOffset.UTC));
            }
            @Override
            public Number fromString(String string) {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        });
        teamASeries = new Series<>();
        teamASeries.setName(service.getGame().getTeamA());
        teamBSeries = new Series<>();
        teamBSeries.setName(service.getGame().getTeamB());
        chart.getData().addAll(teamASeries, teamBSeries); 
    }

    private void startGame() {
        buttonStart.setDisable(true);
        buttonStop.setDisable(false);
        enableGame(true);
        addPeriodEvent(1);
    }

    private void stopGame() {
        buttonStop.setDisable(true);
        enableGame(false);
        addPeriodEvent(5);
    }

    private void addPeriodEvent(int period) {
        addPeriodEvent(period, LocalDateTime.now());
    }
    
    private void addPeriodEvent(int period, LocalDateTime time) {
        this.period.set(period);
        service.addGameEvent(new GameEvent(time, period));
        for (int i = 0; i < 4; i++) {
            periods.get(i).setDisable(i != period);
        }
    }
    
    private void addScoreEvent(int score, int team) {
        addScoreEvent(score, team, LocalDateTime.now());
    }
    
    private void addScoreEvent(int score, int team, LocalDateTime time) {
        final GameEvent gameEvent = new GameEvent(score, 
                time.toInstant(ZoneOffset.UTC).getEpochSecond(), period.get(), team);
        service.addGameEvent(gameEvent);
        if (team == 1) {
            teamASeries.getData().add(
                    new XYChart.Data<>(gameEvent.getDateTime(), 
                            service.getGame().getScoreA()));
        } else {
            teamBSeries.getData().add(
                new XYChart.Data<>(gameEvent.getDateTime(), 
                        service.getGame().getScoreB()));
        }
    }
        
    private void enableGame(boolean value) {
        dropdown.setDisable(!value);
        for (Button button : buttons) {
            button.setDisable(!value);
        }
    }
    
    public void restoreGame(String gameName) {
        teamASeries.getData().clear();
        teamBSeries.getData().clear();
        final String[] split = gameName.split("-");
        service.getGame().setTeamA(split[1]);
        service.getGame().setTeamB(split[2]);
        service.getGame().setScoreA(0);
        service.getGame().setScoreB(0);
        period.set(1);
        dropdown.setSelectedItem(period1);
        final GluonObservableList<GameEvent> retrievedGame = service
                .retrieveGame(gameName);
        
        enableGame(false);
        buttonStart.setDisable(false);
        buttonStop.setDisable(true);
        
        retrievedGame.initializedProperty().addListener((obs, ov, nv) -> {
            if (nv) {
                teamASeries.setName(service.getGame().getTeamA());
                teamBSeries.setName(service.getGame().getTeamB());
                service.getGame().setGameEvents(retrievedGame);
                for (GameEvent event : retrievedGame) {
                    service.updateScore(event);
                    if (event.getScore() == 0) {
                        final int gamePeriod = event.getPeriod();
                        period.set(gamePeriod);
                        if (gamePeriod == 5) {
                            buttonStop.setDisable(true);
                            enableGame(false);
                        } else {
                            buttonStart.setDisable(true);
                            buttonStop.setDisable(false);
                            enableGame(true);
                            if (gamePeriod - 2 >= 0) {
                                periods.get(gamePeriod - 2).setDisable(true);
                            }
                            dropdown.setSelectedItem(periods.get(gamePeriod - 1));
                        }
                    } else {
                        if (event.getTeam() == 1) {
                            teamASeries.getData().add(
                                    new XYChart.Data<>(event.getDateTime(), 
                                            service.getGame().getScoreA()));
                        } else {
                            teamBSeries.getData().add(
                                new XYChart.Data<>(event.getDateTime(), 
                                            service.getGame().getScoreB()));
                        }
                    }
                }
            }
        });
    }
}
