package org.jfxbe.chap13;

import javafx.application.Application;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class HelloMobile extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Rectangle2D bounds = Screen.getPrimary().getVisualBounds();
        final Button button = new Button("Hello Mobile World!");
        button.setStyle("-fx-font-size: 20pt;");
        button.setOnAction(e -> button.setRotate(button.getRotate() - 30));
        
        final StackPane stackPane = new StackPane(button);

        Scene scene = new Scene(stackPane, bounds.getWidth(), bounds.getHeight());
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
